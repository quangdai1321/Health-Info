"""
Chạy thực nghiệm 3 cấu hình trên bộ 150 phiếu tổng hợp.

    baseline    Đưa giá trị thô cho LLM, hỏi "giải thích cho bệnh nhân".
                Không có tầng 2, không ràng buộc, không kiểm chứng.
    constrained Tầng 1-3: LLM nhận nhãn đã phân loại + 3 lớp ràng buộc.
    full        Tầng 1-4: thêm kiểm chứng tự động, sinh lại nếu không đạt.

Kết quả lưu dần ra file, chạy lại sẽ bỏ qua phần đã xong.

Dùng:
    python run_experiment.py                      # cả 3 cấu hình, 150 phiếu
    python run_experiment.py --limit 5            # chạy thử 5 phiếu
    python run_experiment.py --config baseline    # một cấu hình
"""

import sys
import argparse
import json
import re
import time
from pathlib import Path

import urllib.request
import urllib.error

from classifier import RuleClassifier
from prompt_builder import SYSTEM_PROMPT, build_prompt, validate, fallback

ROOT = Path(__file__).resolve().parent.parent
PANELS = ROOT / "data" / "synthetic_panels.json"
RESULTS = ROOT / "results"

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "qwen2.5:3b"
MAX_RETRY = 2          # số lần sinh lại ở cấu hình full


# ------------------------------------------------------------------ gọi model

# Mô hình đang chạy. Các hàm run_* không nhận tham số model, nên nếu chỉ truyền
# --model cho hàm run() thì tên file kết quả đổi mà mô hình được gọi vẫn là mặc
# định — tức là chạy nhầm mô hình trong im lặng. Đặt ở đây để một chỗ duy nhất
# quyết định, và main() gán lại theo --model.
MODEL_DANG_CHAY = MODEL


def call_ollama(messages, model=None, timeout=1800, num_predict=2048):
    """
    Gọi Ollama qua HTTP. Trả về (text, thời gian giây).

    num_predict phải đủ lớn: một phiếu 18 chỉ số cần ~50 token mỗi chỉ số
    cộng cấu trúc JSON, vượt xa mức 800 ban đầu. Đầu ra bị cắt cụt sẽ
    thành JSON không hợp lệ và bị tính nhầm thành lỗi của mô hình.

    timeout trước đây là 300 giây, đủ cho qwen2.5:3b (trung bình 38 giây) nhưng
    không đủ cho 7b trên cùng máy này (trung bình 215 giây, phiếu nặng vượt 300).
    Đây là trần chờ phản hồi, không phải tham số sinh, nên nới ra không làm lệch
    kết quả đã có của 3b.
    """
    payload = {
        "model": model or MODEL_DANG_CHAY,
        "messages": messages,
        "stream": False,
        "format": "json",          # ép đầu ra là JSON hợp lệ
        "options": {"temperature": 0.2, "num_predict": num_predict},
    }
    req = urllib.request.Request(
        OLLAMA_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    return data["message"]["content"], time.time() - t0


def parse_json(text):
    """Bóc JSON khỏi đầu ra, chịu được trường hợp model bọc trong ```."""
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text), None
    except json.JSONDecodeError as e:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            try:
                return json.loads(m.group()), None
            except json.JSONDecodeError:
                pass
        return None, str(e)


# ------------------------------------------------------------------ cấu hình

BASELINE_SYSTEM = (
    "Bạn là trợ lý y tế. Hãy giải thích kết quả xét nghiệm cho bệnh nhân hiểu."
)


def baseline_prompt(panel):
    """
    Cấu hình đối chứng: đưa thẳng giá trị thô, không nhãn, không ràng buộc.
    Mô phỏng cách người dùng thường hỏi thẳng một chatbot.
    """
    lines = []
    for name, payload in panel["results"].items():
        value, unit = (payload[0], payload[1]) if isinstance(payload, (list, tuple)) else (payload, "")
        lines.append(f"- {name}: {value} {unit}".rstrip())

    return (
        "Đây là kết quả xét nghiệm máu của tôi:\n\n"
        + "\n".join(lines)
        + '\n\nHãy giải thích cho tôi hiểu. Trả về JSON dạng '
          '{"items": [{"code": "...", "plain_name": "...", '
          '"status": "cao|thap|trong_khoang", "explanation": "..."}], "closing": "..."}'
    )


def run_baseline(panel, classified):
    text, dt = call_ollama([
        {"role": "system", "content": BASELINE_SYSTEM},
        {"role": "user", "content": baseline_prompt(panel)},
    ])
    out, err = parse_json(text)
    if out is None:
        return {"output": None, "parse_error": err, "raw_tail": text[-300:], "raw_len": len(text),
                "validation": {"passed": False, "violations": [{"type": "unparseable"}]},
                "seconds": dt, "attempts": 1}
    return {"output": out, "parse_error": None,
            "validation": validate(out, classified),   # chấm bằng cùng thước đo
            "seconds": dt, "attempts": 1}


def run_constrained(panel, classified):
    text, dt = call_ollama([
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": build_prompt(classified)},
    ])
    out, err = parse_json(text)
    if out is None:
        return {"output": None, "parse_error": err, "raw_tail": text[-300:], "raw_len": len(text),
                "validation": {"passed": False, "violations": [{"type": "unparseable"}]},
                "seconds": dt, "attempts": 1}
    return {"output": out, "parse_error": None,
            "validation": validate(out, classified),
            "seconds": dt, "attempts": 1}


def run_full(panel, classified):
    """Tầng 1-4: sinh lại tối đa MAX_RETRY lần, không đạt thì dùng mẫu cố định."""
    total, attempts, last = 0.0, 0, None

    for attempt in range(1, MAX_RETRY + 2):
        attempts = attempt
        text, dt = call_ollama([
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": build_prompt(classified)},
        ])
        total += dt
        out, _ = parse_json(text)
        if out is None:
            continue
        v = validate(out, classified)
        last = (out, v)
        if v["passed"]:
            return {"output": out, "parse_error": None, "validation": v,
                    "seconds": total, "attempts": attempts, "used_fallback": False}

    fb = fallback(classified)
    return {"output": fb, "parse_error": None,
            "validation": validate(fb, classified),
            "seconds": total, "attempts": attempts, "used_fallback": True,
            "last_rejected": last[0] if last else None}


# ------------------------------------------------- cấu hình tách phần (ablation)
# Phản biện vòng 2: cấu hình "constrained" gộp ba thứ (nhãn từ luật, ràng buộc nội
# dung trong prompt, khuôn JSON) nên không tách được phần nào đóng góp bao nhiêu,
# và thiếu cấu hình chỉ có kiểm chứng. Ba cấu hình dưới đây tách chúng ra.

# Giống SYSTEM_PROMPT nhưng bỏ hẳn phần cấm nội dung, để đo riêng tác dụng của nhãn.
SYSTEM_CHI_NHAN = (
    "Bạn là trợ lý giải thích kết quả xét nghiệm cho người bệnh. "
    "Hãy diễn đạt lại thông tin đã cho bằng ngôn ngữ đời thường, dễ hiểu."
)


def cham_an_toan(out, classified):
    """Chấm nhưng không để vỡ vòng chạy.

    Ở các cấu hình không ép khuôn JSON chặt, mô hình có lúc trả về "items" là danh
    sách chuỗi thay vì danh sách đối tượng. Bộ chấm văng AttributeError và cả mẻ
    dừng giữa chừng. Đây vẫn là một lần hỏng của cấu hình đó, nên ghi nhận thành
    một loại vi phạm riêng thay vì bỏ qua.
    """
    try:
        return validate(out, classified)
    except (AttributeError, TypeError, KeyError) as e:
        return {"passed": False,
                "violations": [{"type": "malformed_structure",
                                "detail": f"{type(e).__name__}: {e}"}]}


def run_chi_nhan(panel, classified):
    """Chỉ có nhãn từ luật và khuôn JSON. Không có ràng buộc nội dung, không kiểm chứng."""
    text, dt = call_ollama([
        {"role": "system", "content": SYSTEM_CHI_NHAN},
        {"role": "user", "content": build_prompt(classified)},
    ])
    out, err = parse_json(text)
    if out is None:
        return {"output": None, "parse_error": err, "raw_tail": text[-300:], "raw_len": len(text),
                "validation": {"passed": False, "violations": [{"type": "unparseable"}]},
                "seconds": dt, "attempts": 1}
    return {"output": out, "parse_error": None,
            "validation": cham_an_toan(out, classified), "seconds": dt, "attempts": 1}


def run_chi_rang_buoc(panel, classified):
    """Chỉ có ràng buộc nội dung và khuôn JSON. Không đưa nhãn, không kiểm chứng."""
    text, dt = call_ollama([
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": baseline_prompt(panel)},
    ])
    out, err = parse_json(text)
    if out is None:
        return {"output": None, "parse_error": err, "raw_tail": text[-300:], "raw_len": len(text),
                "validation": {"passed": False, "violations": [{"type": "unparseable"}]},
                "seconds": dt, "attempts": 1}
    return {"output": out, "parse_error": None,
            "validation": cham_an_toan(out, classified), "seconds": dt, "attempts": 1}


def run_chi_kiem_chung(panel, classified):
    """Chỉ có tầng 4: vẫn hỏi thẳng như baseline, nhưng kiểm chứng, sinh lại, rồi lùi về bản mẫu."""
    total, attempts, last = 0.0, 0, None
    for attempt in range(1, MAX_RETRY + 2):
        attempts = attempt
        text, dt = call_ollama([
            {"role": "system", "content": BASELINE_SYSTEM},
            {"role": "user", "content": baseline_prompt(panel)},
        ])
        total += dt
        out, _ = parse_json(text)
        if out is None:
            continue
        v = cham_an_toan(out, classified)
        last = (out, v)
        if v["passed"]:
            return {"output": out, "parse_error": None, "validation": v,
                    "seconds": total, "attempts": attempts, "used_fallback": False}
    fb = fallback(classified)
    return {"output": fb, "parse_error": None, "validation": cham_an_toan(fb, classified),
            "seconds": total, "attempts": attempts, "used_fallback": True,
            "last_rejected": last[0] if last else None}


CONFIGS = {"baseline": run_baseline, "constrained": run_constrained, "full": run_full,
           "chi_nhan": run_chi_nhan, "chi_rang_buoc": run_chi_rang_buoc,
           "chi_kiem_chung": run_chi_kiem_chung}


# ------------------------------------------------------------------ vòng chạy

def to_classifier_input(results):
    """JSON đọc lên biến tuple thành list, đưa về dạng classifier nhận."""
    return {
        k: (tuple(v) if isinstance(v, list) else v)
        for k, v in results.items()
    }


def run(config_name, panels, limit=None, model=MODEL, lan=None):
    """lan: số thứ tự lần chạy lặp. Có lan thì ghi ra file riêng, để chạy lại
    cùng cấu hình không bị cơ chế bỏ-qua-phiếu-đã-xong nuốt mất."""
    RESULTS.mkdir(exist_ok=True)
    hau_to = f"_lan{lan}" if lan else ""
    out_path = RESULTS / f"{config_name}_{model.replace(':', '-')}{hau_to}.jsonl"

    done = set()
    if out_path.exists():
        with open(out_path, encoding="utf-8") as f:
            for line in f:
                try:
                    done.add(json.loads(line)["panel_id"])
                except (json.JSONDecodeError, KeyError):
                    pass
        print(f"  đã có {len(done)} phiếu, bỏ qua")

    clf = RuleClassifier()
    todo = [p for p in panels if p["panel_id"] not in done]
    if limit:
        todo = todo[:limit]

    t_start = time.time()
    hong_lien_tiep = 0
    with open(out_path, "a", encoding="utf-8") as f:
        for i, panel in enumerate(todo, 1):
            classified = clf.classify_panel(to_classifier_input(panel["results"]))
            # Một lần lỗi kết nối trước đây làm break cả chặng, và vòng chạy coi
            # như đã xong: chặng dừng ở phiếu thứ 4 mà vẫn in "xong". Giờ thử lại
            # phiếu đó, và chỉ bỏ cuộc khi ba phiếu liên tiếp đều hỏng, tức là
            # Ollama thật sự chết chứ không phải một phiếu nặng.
            res = None
            for lan_thu in (1, 2, 3):
                try:
                    res = CONFIGS[config_name](panel, classified)
                    hong_lien_tiep = 0
                    break
                except (urllib.error.URLError, TimeoutError, OSError) as e:
                    print(f"\n  lỗi kết nối ở {panel['panel_id']} (lần {lan_thu}): {e}")
                    time.sleep(10)
            if res is None:
                hong_lien_tiep += 1
                print(f"  bỏ qua {panel['panel_id']} sau 3 lần thử "
                      f"({hong_lien_tiep} phiếu hỏng liên tiếp)")
                if hong_lien_tiep >= 3:
                    print("  DỪNG: ba phiếu liên tiếp hỏng, kiểm tra Ollama rồi chạy lại.")
                    break
                continue

            rec = {
                "panel_id": panel["panel_id"],
                "config": config_name,
                "model": model,
                "target_label": panel["target_label"],
                "rule_label": classified["overall_label"],
                "n_analytes": len(classified["findings"]),
                "n_rejected_unit": len(classified["rejected_unknown_unit"]),
                **res,
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f.flush()

            elapsed = time.time() - t_start
            eta = elapsed / i * (len(todo) - i)
            ok = "✓" if res["validation"]["passed"] else "✗"
            print(f"  [{i}/{len(todo)}] {panel['panel_id']} {ok} "
                  f"{res['seconds']:.1f}s  còn ~{eta/60:.0f} phút", end="\r")

    print(f"\n  xong -> {out_path.name}")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", choices=list(CONFIGS) + ["all"], default="all")
    ap.add_argument("--limit", type=int, default=None, help="số phiếu, để thử nhanh")
    ap.add_argument("--model", default=MODEL)
    ap.add_argument("--lan", type=int, default=None,
                    help="số thứ tự lần chạy lặp, ghi ra file riêng")
    args = ap.parse_args()

    global MODEL_DANG_CHAY
    MODEL_DANG_CHAY = args.model

    panels = json.loads(PANELS.read_text(encoding="utf-8"))
    names = list(CONFIGS) if args.config == "all" else [args.config]

    for name in names:
        lan = f", lần {args.lan}" if args.lan else ""
        print(f"\n=== {name} ({args.model}{lan}) ===")
        run(name, panels, args.limit, args.model, args.lan)


if __name__ == "__main__":
    # Console Windows mac dinh dung cp1252, khong in duoc tieng Viet -> ep UTF-8.
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    main()
