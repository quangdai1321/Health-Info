HI26-0013 — Source file and supplementary material
==================================================

Paper: A Rule-Constrained Large Language Model Pipeline for Rule-Consistent
       Explanation of Vietnamese Complete Blood Count Results

The camera-ready form has no upload field for supplementary material, and the
paper refers to Appendices A, B and C. They are included here together with the
editable source, so that nothing the paper cites is missing.

Contents
--------

  HI26-0013_Camera-Ready_Paper.docx
      Editable source of the submitted PDF. Word, HEALTHINFO IV template.

  HI26-0013_Supplementary-Appendices.pdf
      Appendix A  Benchmark distributions, reference intervals, severity
                  factors, unit conversions and the alias table.
      Appendix B  Full specification of the Layer 4 validator: algorithm,
                  pattern tables, masking rules, and a false-positive mode we
                  found and disclose.
      Appendix C  One worked example per error class, taken from the run logs.

  code-and-data/
      Source code, the generated benchmark, and the raw output of every run
      reported in the paper, one JSON object per panel. See its README.md for
      how to reproduce. All seven configurations on Qwen2.5-3B, three
      configurations on Qwen2.5-7B, and five repeated runs are included.

Contact: Vo Hoang Khang, vh.khang@hutech.edu.vn
