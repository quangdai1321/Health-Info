# Supplementary Materials

**A Rule-Constrained Large Language Model Pipeline for Patient-Friendly Interpretation of Vietnamese Blood Test Results**
HEALTHINFO IV, Track B (Health Literacy)

This archive contains the code, synthetic data, and raw outputs behind Tables 1–2 of the paper.
No patient data is included: all 150 complete blood count panels are synthetic.

## Contents

```
data/
  reference_ranges.csv        22 CBC analytes: reference intervals, units, severity factors (s_j)
  synthetic_panels.json       150 synthetic panels with ground-truth labels (seed 42)
src/
  classifier.py               Layer 1 (name/unit normalisation) + Layer 2 (rule-based classification)
  prompt_builder.py           Layer 3 (constrained prompt) + Layer 4 (validation, regeneration, fallback)
  generate_data.py            Regenerates data/synthetic_panels.json byte-for-byte
  run_experiment.py           Runs the three configurations through Ollama
  analyze.py                  Aggregates results/*.jsonl into results/summary.csv
tests/
  test_classifier.py          38 unit tests for Layers 1–2
results/
  baseline_qwen2.5-3b.jsonl   One line per panel (150 each)
  constrained_qwen2.5-3b.jsonl
  full_qwen2.5-3b.jsonl
  summary.csv                 Source of the figures in Table 2
requirements.txt              pytest only; the pipeline uses the Python standard library
```

## Requirements

- Python 3.10+
- `pip install -r requirements.txt` (pytest, for the tests only)
- For re-running the experiment: [Ollama](https://ollama.com) and `ollama pull qwen2.5:3b`

## Usage

```bash
python -m pytest tests/ -q            # expected: 38 passed
python src/classifier.py              # Layer 1-2 demo
python src/prompt_builder.py          # prompt and validator demo
python src/generate_data.py           # regenerate the 150 synthetic panels
python src/analyze.py                 # recompute results/summary.csv from the raw outputs
```

Full re-run (about 6 hours on CPU):

```bash
python src/run_experiment.py --limit 3   # smoke test
python src/run_experiment.py             # 150 panels x 3 configurations
python src/analyze.py
```

The run resumes automatically if interrupted. Measured on an Intel Core i5-9400F, 24 GB RAM, no GPU:
mean 38.9 s (baseline), 35.8 s (constrained), and 68.3 s (full) per panel.

## Error classes checked by Layer 4

| Code | Meaning |
|---|---|
| `false_reassurance` | Closing statement says all results are normal on an abnormal panel |
| `status_mismatch` | Structured status field disagrees with the Layer 2 label (direction mismatch) |
| `contradictory_wording` | Prose contradicts the label although the status field is correct |
| `forbidden_term` | Disease names, causes, medications, or treatments |
| `hallucinated_analyte` | Analyte not present in the input (fabricated) |
| `missing_analyte` | Analyte from the input omitted |

`code_format` (display name instead of canonical code) and unparseable JSON are counted separately as formatting errors.

In the `full` configuration, 100% of outputs pass validation: 64.0% are model-generated text and 36.0% are fixed-template fallbacks.

## Limitations

The severity factors are heuristic and are not clinical recommendations. Outputs were not reviewed by medical professionals.
This software is a research prototype and must not be used for clinical decisions.
